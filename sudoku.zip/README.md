# Sudoku — versione HTML/CSS/JS

Versione statica dell'app Blazor: nessun server, basta aprire `index.html` nel browser
(doppio clic) o pubblicare la cartella su un qualsiasi hosting statico.

| File | Contenuto |
| --- | --- |
| `index.html` | struttura della pagina e applicazione del tema prima del disegno |
| `style.css` | copia di `wwwroot/app.css` |
| `puzzles.js` | la raccolta, generata da `Data/puzzles.json` |
| `app.js` | risolutore, logica di gioco, interfaccia, tastiera e puntatore |

Comandi, impostazioni, cronologia e salvataggi (`localStorage`) sono gli stessi della versione Blazor.
All'avvio i puzzle senza soluzione unica vengono scartati (avviso nella console del browser).

## Aggiornare la raccolta

Dopo aver modificato `Data/puzzles.json`, rigenera `puzzles.js` (dalla cartella `SUDOKU`, in Git Bash):

```bash
{ printf 'window.SUDOKU_PUZZLES = '; cat Data/puzzles.json; printf ';\n'; } > HTML/puzzles.js
```
